<?php $page = 'home'; ?>


<!DOCTYPE html>
<html lang="en">

<head>
    <title>RNB GLOBAL </title>
    <?php include 'include/head-links.php'; ?>
    <meta property="og:url" content="<?php echo $page_url ?>">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="images/logo.png">
    <meta name="twitter:card" content="">
    <meta name="twitter:site" content="<?php echo $page_url ?>">
    <meta name="twitter:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="images/logo.png">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css" />

</head>

<body onload="createCaptcha();">
    <div class="wrapper ">
        <?php include 'include/header.php'; ?>
        <div class="banner-wrapper ">
            <div class="containerFull">
                <img src="images/banner/rural-exellence.png" alt="" class="img-fluid w-100" />
            </div>
        </div>
        <section>
            <div class="containerFull ">
                <div class="px-5">

                    <div class="row">
                        <div class="col-lg-6">

                            <h1 class="text_primary heading fontHeading fontWeight900">
                                Rural Excellence
                            </h1>
                        </div>
                        <div class="col-lg-6">

                            <div class="row align-items-center">
                                <div class="col-lg-6">
                                    <img class="w-100" src="images/icons/7.png" alt="" />

                                </div>
                                <div class="col-lg-6">
                                    <h4 class="heading fontWeight600 text_secondary">
                                        Gross <br /> Enrollment <br />Ratio
                                    </h4>
                                </div>



                            </div>
                            <p class="mt-4">

                                That’s the abysmal percentage of rural children enrolled in higher education out of the
                                total population in the relevant age group.
                            </p>
                            <p class="mt-4">

                                With limited access to educational institutes, lack of employment opportunities, and
                                resource constraints, these students need a leg up in life.
                            </p>
                        </div>

                    </div>
                </div>

            </div>
        </section>
        <section>
            <div class="containerFull">
                <div class="px-5">
                    <h4 class="text_primary heading fontWeight600">Addressing Rural Challenges</h4>

                    <?php
                    $vertical_impacts = [
                        [
                            'description' => 'Through its rural presence, RNB Global University positively impacts the rural Gross Enrollment Rate (GER) of Rajasthan and India.',
                            'icon' => 'earth.png',
                            'image' => 'rural-impact.jpg',

                        ],
                        [
                            'description' => 'Access to scholarships and financial aids make education affordable for deserving students.',
                            'icon' => 'degree.png',
                            'image' => 'scholarship.jpg',

                        ],
                        [
                            'description' => 'Job readiness workshops at the end of each course enable students to easily integrate into jobs and industry.',
                            'icon' => 'board.png',
                            'image' => 'job-workshop.jpg',

                        ],
                        [
                            'description' => 'Partnerships with companies provide jobs to youth while creating a skilled workforce for the industry.',
                            'icon' => 'partnerships.png',
                            'image' => 'industry-partnership.jpg',

                        ]
                    ];
                    ?>
                    <!-- <?= $impact['image'] ?> -->

                    <?php foreach ($vertical_impacts as $impact): ?>
                        <div class="rural-challenges  mb-4">
                            <div class="image">
                                <img src="images/rural-exellence/challenge-1.png" alt="impact image" class="img-fluid ">

                            </div>
                            <div class="content ">

                                <img src="images/icons/<?= $impact['icon'] ?>" alt="icon" class="icon-img">
                                <p class="mb-0"><?= $impact['description'] ?></p>
                            </div>
                        </div>
                    <?php endforeach; ?>



                </div>

            </div>
        </section>



        <section class="pt-0">
            <div class="containerFull">
                <div class="px-5">

                    <h4 class="heading fontWeight600 text_primary">
                        Connect with us today.
                    </h4>
                    <div class="mt-5">
                        <a class="btn_2 px-5" href="/">

                            contact us
                        </a>

                    </div>
                </div>


            </div>
        </section>
        <?php include 'include/footer.php'; ?>
    </div>
    <?php include 'include/footer-links.php'; ?>
    <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
    <script>
        var swiper = new Swiper(".awards_slider", {
            spaceBetween: 20,
            centeredSlides: true,
            slidesPerView: 1.5,
            loop: true,
            autoplay: {
                delay: 5000,
                disableOnInteraction: false,
            },

            // breakpoints: {

            //     320: {
            //         slidesPerView: 1,
            //         spaceBetween: 10
            //     },

            //     480: {
            //         slidesPerView: 1,
            //         spaceBetween: 20
            //     },

            //     640: {
            //         slidesPerView: 2,
            //         spaceBetween: 30
            //     },

            //     768: {
            //         slidesPerView: 2,
            //         spaceBetween: 30
            //     }
            //     1024: {
            //         slidesPerView: 3,
            //         spaceBetween: 30
            //     }
            // }
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },

            navigation: {
                nextEl: ".next_1",
                prevEl: ".prev_1",
            },
        });
    </script>

</body>

</html>